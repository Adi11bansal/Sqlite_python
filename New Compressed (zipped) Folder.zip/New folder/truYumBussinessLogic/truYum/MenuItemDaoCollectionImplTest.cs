﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.truyum.model;
using com.cognizant.truyum.util;


namespace com.cognizant.truyum.dao
{
    public class MenuItemDaoCollectionImplTest
    {
        
        public static void Main(string[] args)
        { 
            //string y;
            int choice = 0;
                
                MenuItemDaoCollectionImplTest mtest = new MenuItemDaoCollectionImplTest();
                while (choice != 3)
                {

                    Console.WriteLine("1. Admin \n2. Customer \n3.Exit \nEnter your choice :");
                    choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: mtest.TestGetMenuItemListAdmin();

                            Console.WriteLine("Do you want to Edit");
                            string ans = Console.ReadLine();
                            while (ans == "y")
                            {
                                ans = "";
                                MenuItemDaoCollectionImpl mcol = new MenuItemDaoCollectionImpl();
                                Console.WriteLine("Enter the ID to edit the MenuItem : ");
                                int id = int.Parse(Console.ReadLine());
                                MenuItem m = mcol.GetMenuItem(id);
                                if (m == null)
                                    Console.WriteLine("Invalid Id");
                                else
                                {
                                    mcol.ModifyProduct(m);

                                    Console.WriteLine("Record updated successfully\n\n");

                                }
                                ans = "";
                                Console.WriteLine("Do you want to Edit(y/n)");
                                ans = Console.ReadLine();
                            }
                            break;
                       
                        
                        case 2: mtest.TestGetMenuItemListCustomer();
                            Console.WriteLine("1.Add to Cart\n2.Remove Item from Cart");
                            int option = int.Parse(Console.ReadLine());
                            CartDaoCollectionImplTest ctest = new CartDaoCollectionImplTest();
                            switch (option)
                            {
                                case 1: ctest.TestAddCartItem();
                                    break;
                                case 2: ctest.TestRemoveCartItem();
                                    break;
                                //case 3: ctest.TestGetAllCartItems();
                                //    break;

                            }
                            break;
                       
                        case 3:
                            break;

                    }
                    //Console.WriteLine("Do you want to continue?(y/n)");
                    //y = Console.ReadLine();
                }
            Console.ReadKey();
        }
        public void TestGetMenuItemListAdmin()
        {
            MenuItemDaoCollectionImpl lst = new MenuItemDaoCollectionImpl();
            List<MenuItem> menulist = lst.GetMenuItemListAdim();
            foreach (MenuItem menu in menulist)
            {
                Console.WriteLine(menu.ToString());
            }
        }
        public void TestGetMenuItemListCustomer()
        {
            MenuItemDaoCollectionImpl lst = new MenuItemDaoCollectionImpl();
            List<MenuItem> menulist = lst.GetMenuItemListCustomer();
            foreach (MenuItem menu in menulist)
            {
                Console.WriteLine(menu.ToString());
            }
        }
        
    }
}
