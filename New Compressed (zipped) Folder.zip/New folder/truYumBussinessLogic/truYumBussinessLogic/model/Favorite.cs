﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.moviecruiser.model
{
    public class Favorite
    {
        public static List<MovieItem> movieItemList = new List<MovieItem>();
        double total;
        public List<MovieItem> MovieItemList
        {
            get { return movieItemList; }
            set { movieItemList = value; }
        }
        public double Total
        {
            get { return total; }
            set { total = value; }
        }
        public Favorite() { }
        public Favorite(List<MovieItem> movieItemListt,double total)
        {
            movieItemList = movieItemListt;
            this.total = total;
        }
    }
}
