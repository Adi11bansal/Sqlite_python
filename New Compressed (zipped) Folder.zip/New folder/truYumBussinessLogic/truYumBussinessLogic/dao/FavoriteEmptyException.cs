﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace com.cognizant.moviecruiser.dao
{
    class FavoriteEmptyException:Exception
    {
        public string message;
        public FavoriteEmptyException()
        {
            message="Favorite is empty.";
        }
        
    }
}
