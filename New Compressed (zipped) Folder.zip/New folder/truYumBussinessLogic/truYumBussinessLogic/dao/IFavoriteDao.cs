﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.moviecruiser.model;
using System.IO;

namespace com.cognizant.moviecruiser.dao
{
    interface IFavoriteDao
    {
        void AddFavoriteItem(long userId, long movieItemId);
        Favorite GetAllFavoriteItems(long userId);
        int RemoveFavoriteItem(long userId, long productId);
    }
}
