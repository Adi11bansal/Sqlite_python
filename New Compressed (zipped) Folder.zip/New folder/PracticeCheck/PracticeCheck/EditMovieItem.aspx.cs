﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.moviecruiser.dao;
using com.cognizant.moviecruiser.util;
using com.cognizant.moviecruiser.model;
using MovieItem = com.cognizant.moviecruiser.model.MovieItem;

namespace PracticeCheck
{
    public partial class EditMovieItem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MovieItemDaoCollectionImpl movieListDaoImpl = new MovieItemDaoCollectionImpl();
                MovieItem movieItemList = movieListDaoImpl.GetMovieItem(Convert.ToInt32(Session["Name"].ToString()));
                TextBox1.Text = movieItemList.Name;
                TextBox2.Text = movieItemList.Budget.ToString();
                TextBox4.Text = movieItemList.DateOfLaunch.ToString();
                DropDownList1.Text = movieItemList.Genre;
                CheckBox1.Checked = movieItemList.HasTeaser;
                if (movieItemList.Active)
                {
                    RadioButton1.Checked = true;
                    RadioButton2.Checked = false;
                }
                else
                {
                    RadioButton1.Checked = false;
                    RadioButton2.Checked = true;
                }
                
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            MovieItemDaoCollectionImpl movieItemDaoImpl = new MovieItemDaoCollectionImpl();
            MovieItem movieList = movieItemDaoImpl.GetMovieItem(Convert.ToInt32(Session["Name"].ToString()));

            movieItemDaoImpl.GetMovieItemListAdmin().Remove(movieList);

            movieList.Name = TextBox1.Text;
            movieList.Budget = float.Parse(TextBox2.Text);
            movieList.HasTeaser = CheckBox1.Checked;
            //movieList.Active = RadioButton1.Checked;
            //movieList.Active = RadioButton2.Checked;
            //if (movieList.Active)
            //{
            //    RadioButton1.Checked = true;
            //    RadioButton2.Checked = false;
            //}
            //else
            //{
            //    RadioButton1.Checked = false;
            //    RadioButton2.Checked = true;
            //}
            if (RadioButton1.Checked)
            {
                movieList.Active = true;
            }
            else
            {
                movieList.Active = false;
            }
            movieList.DateOfLaunch = Convert.ToDateTime(TextBox4.Text);
            movieList.Genre = DropDownList1.Text;

            movieItemDaoImpl.GetMovieItemListAdmin().Add(movieList);
            Response.Redirect("EditMovieItemStatus.aspx");


        }

        
    }
}