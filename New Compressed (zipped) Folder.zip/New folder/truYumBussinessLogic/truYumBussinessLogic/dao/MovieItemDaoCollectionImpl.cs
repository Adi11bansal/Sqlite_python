﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.moviecruiser.model;
using com.cognizant.moviecruiser.util;

namespace com.cognizant.moviecruiser.dao
{
    public class MovieItemDaoCollectionImpl:IMovieItemDao
    {
        public static List<MovieItem> movieItemList = new List<MovieItem>()
        {
          
                    new MovieItem(){ Id=101,Name="Avengers",Budget=5000000,Active=true,Genre="Action",DateOfLaunch=DateUtil.ConvertToDate("10/12/2018"),HasTeaser=true},
                    new MovieItem(){ Id =102, Name="Avengers2", Budget = 3500000, Active =true, Genre ="Action", DateOfLaunch=DateUtil.ConvertToDate("11/02/2019"), HasTeaser=true},
                    new MovieItem(){ Id =103, Name="Avengers3", Budget = 1250000, Active =true, Genre ="Action", DateOfLaunch=DateUtil.ConvertToDate("20/12/2018"), HasTeaser=true},
                    new MovieItem(){ Id =104, Name="Avengers4", Budget = 570000, Active =false, Genre ="Action", DateOfLaunch=DateUtil.ConvertToDate("15/08/2019"), HasTeaser=true},    
                    new MovieItem(){ Id=105,Name="Avengers5 ",Budget=320000,Active=true,Genre="Action",DateOfLaunch=DateUtil.ConvertToDate("02/11/2022"),HasTeaser=true}
               
        };
    


        public List<MovieItem>GetMovieItemListAdmin()
        {
            return movieItemList;
        }

        
        public List<MovieItem> GetMovieItemListCustomer()
        {
            List<MovieItem> itemCustomer = new List<MovieItem>();
            foreach (MovieItem item in movieItemList)
            {
                if ((((item.DateOfLaunch).Subtract(DateTime.Now)).Days) < 0 && item.Active == true)
                {
                    itemCustomer.Add(item);
                }
            }

            return itemCustomer;
        }

    public void ModifyProduct(MovieItem movieItem)
        {
            Console.WriteLine("Enter Details to Edit \nEnter Name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Budget");
            float budget = float.Parse(Console.ReadLine());
            Console.WriteLine("Active");
            Boolean active = Boolean.Parse(Console.ReadLine());
            Console.WriteLine("Date Of Launch");
            DateTime dateOfLaunch = DateUtil.ConvertToDate(Console.ReadLine());
            Console.WriteLine("Genre");
            string genre = Console.ReadLine();
            Console.WriteLine("Free Delivery");
            Boolean hasteaser = Boolean.Parse(Console.ReadLine());
            
            movieItem.Name = name;
            movieItem.Budget = budget;
            movieItem.Active = active;
            movieItem.DateOfLaunch = dateOfLaunch;
            movieItem.Genre = genre;
            movieItem.HasTeaser = hasteaser;
        }

    public MovieItem GetMovieItem(long movieItemId)
        {
            foreach (MovieItem movie in movieItemList)
            {
                if (movie.Id == movieItemId)
                    return movie;
            }

            return null;
        }
    }
}
