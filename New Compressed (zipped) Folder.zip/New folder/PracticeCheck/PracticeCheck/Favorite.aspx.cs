﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.moviecruiser.dao;
using com.cognizant.moviecruiser.model;
using com.cognizant.moviecruiser.util;
using MovieItem = com.cognizant.moviecruiser.model.MovieItem;
using System.ComponentModel;
using System.Data;


namespace PracticeCheck
{
    public partial class Favorite : System.Web.UI.Page
    {
        static int Flag=0;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable getFavoriteListTable = CreateTable.ToDataTable<MovieItem>(FavoriteDaoCollectionImpl.userFavorite[1].MovieItemList);
            GridView1.DataSource = getFavoriteListTable;
            GridView1.DataBind();
            if (Flag == 1)
            {
                Label2.Text = "Item removed from favorite successfully";
            }

            Label4.Text = (FavoriteDaoCollectionImpl.userFavorite[1].Total).ToString();

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Session["Delete"] = GridView1.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Text.ToString();

            MovieItemDaoCollectionImpl myList = new MovieItemDaoCollectionImpl();
            FavoriteDaoCollectionImpl favoriteList = new FavoriteDaoCollectionImpl();
            MovieItem movieItem = myList.GetMovieItem(Convert.ToInt32(Session["Delete"].ToString()));

            long p = movieItem.Id;
            int getRemoveMovieId =  favoriteList.RemoveFavoriteItem(1,p);
            Flag = 1;
            if (getRemoveMovieId ==0)
            {
                Response.Redirect("~/FavoriteEmpty.aspx");
            }
            Response.Redirect("~/Favorite.aspx");
            

        }
    }
}