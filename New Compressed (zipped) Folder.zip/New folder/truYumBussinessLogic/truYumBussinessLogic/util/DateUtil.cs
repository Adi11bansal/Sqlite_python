﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
namespace com.cognizant.moviecruiser.util
{
    public class DateUtil
    {
        public static DateTime ConvertToDate(string inDate)
        { 
            DateTime outDate;
            DateTime.TryParseExact(inDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out outDate);
            return outDate;
        }
    }
}
