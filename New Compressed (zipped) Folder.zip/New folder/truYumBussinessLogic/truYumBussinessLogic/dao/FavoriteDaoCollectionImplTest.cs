﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.moviecruiser.model;

namespace com.cognizant.moviecruiser.dao
{
    public class FavoriteDaoCollectionImplTest
    {
        public void TestAddFavoriteItem()
        {
            IFavoriteDao favoriteDao = new FavoriteDaoCollectionImpl();
            Console.WriteLine("Enter Movie Item Id:");
            int add = int.Parse(Console.ReadLine());
            favoriteDao.AddFavoriteItem(1, add);
            
            Favorite favoriteFinal = new Favorite();
            favoriteFinal = favoriteDao.GetAllFavoriteItems(1);
            foreach (MovieItem item in favoriteFinal.MovieItemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Total Amount:" + favoriteFinal.Total);

        }
        public void TestGetAllFavoriteItems()
        {

        }
        public void TestRemoveFavoriteItem()
        {
            IFavoriteDao favoriteDao = new FavoriteDaoCollectionImpl();
            Console.WriteLine("Enter Movie Item to delete:");
            int delete = int.Parse(Console.ReadLine());
            favoriteDao.RemoveFavoriteItem(1, delete);
            try
            {
                Favorite favoriteFinal = new Favorite();
                favoriteFinal = favoriteDao.GetAllFavoriteItems(1);
                if (favoriteFinal.MovieItemList.Count == 0)
                {
                    throw new FavoriteEmptyException();
                }
                else
                {
                    foreach (MovieItem item in favoriteFinal.MovieItemList)
                    {
                        Console.WriteLine(item);
                    }
                }
                Console.WriteLine("Total Amount:" + favoriteFinal.Total);
            }
            //catch (FavoriteEmptyException ex1)
            //{
            //    Console.WriteLine(ex1.getmess());
            //}
            catch (FavoriteEmptyException e)
            {
                Console.WriteLine(e.message);
            }

        }
        
    }
}
