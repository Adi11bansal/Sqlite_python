﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.moviecruiser.dao;
using com.cognizant.moviecruiser.model;
using System.Data;
using MovieItem = com.cognizant.moviecruiser.model.MovieItem;
using System.ComponentModel;


namespace PracticeCheck
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MovieItemDaoCollectionImpl movieItemDaoCollectionImpl = new MovieItemDaoCollectionImpl();
            List<MovieItem> getList = movieItemDaoCollectionImpl.GetMovieItemListAdmin();
            DataTable getAdminListTable = CreateTable.ToDataTable<MovieItem>(getList);
            GridView1.DataSource = getAdminListTable;
            GridView1.DataBind();


        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.ToString() == "Edit")
            {
                Session["Name"] = GridView1.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Text.ToString();
                Response.Redirect("~/EditMovieItem.aspx");

            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}