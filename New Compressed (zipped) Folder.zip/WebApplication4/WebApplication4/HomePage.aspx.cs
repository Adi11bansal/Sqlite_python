﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace WebApplication4
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataSet ds = new DataSet();
                ds.ReadXml(@"c:\users\799204\documents\visual studio 2012\Projects\WebApplication4\WebApplication4\XMLFile1.xml");
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.ToString() == "Update")
            {

                //Session["Update"] = GridView1.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Text.ToString();

                Response.Write(GridView1.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Text.ToString() + "   " + GridView1.Rows[Convert.ToInt32(e.CommandArgument)].Cells[2].Text.ToString());

                //Response.Redirect("~/EditMenuItem.aspx");

            }

            else if (e.CommandName.ToString() == "Cancel")
            {

                Response.Redirect("~/HomePage.aspx");

            }
        }
    }
}