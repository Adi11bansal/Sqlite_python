﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.moviecruiser.model;

namespace com.cognizant.moviecruiser.dao
{
    interface IMovieItemDao
    {
        List <MovieItem> GetMovieItemListAdmin();
        List<MovieItem> GetMovieItemListCustomer();
        void ModifyProduct(MovieItem movieItem);
        MovieItem GetMovieItem(long movieItemId);

    }
}
