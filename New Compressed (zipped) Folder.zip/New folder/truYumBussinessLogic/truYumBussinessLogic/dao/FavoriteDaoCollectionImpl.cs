﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using com.cognizant.moviecruiser.model;
using System.Web;
using com.cognizant.moviecruiser.util;

namespace com.cognizant.moviecruiser.dao
{
    public class FavoriteDaoCollectionImpl:IFavoriteDao
    {
        
        public static Dictionary<long, Favorite> userFavorite = new Dictionary<long, Favorite>();
        public FavoriteDaoCollectionImpl()
        {
            if (userFavorite==null)
            {
                userFavorite = new Dictionary<long, Favorite>();
            }
       
        
        }
        
        public void AddFavoriteItem(long userId, long movieItemId)
        {
            double total = 0;
            MovieItemDaoCollectionImpl MovieItemDao = new MovieItemDaoCollectionImpl();
            MovieItem movieItem=MovieItemDao.GetMovieItem(movieItemId);

            List<MovieItem> favoriteMovie = new List<MovieItem>();
            List<MovieItem> checkMovie = new List<MovieItem>();
            checkMovie = MovieItemDao.GetMovieItemListCustomer();

            foreach (MovieItem item in checkMovie)
            {
                if (item.Id == movieItemId)
                {
                    movieItem = item;
                    favoriteMovie.Add(item);
                    total = total + item.Budget;
                }
            }
            if (userFavorite.ContainsKey(userId))
            {
                userFavorite[userId].MovieItemList.Add(movieItem);
                userFavorite[userId].Total += movieItem.Budget;
            }
            else
            {
                Favorite favorite1 = new Favorite(favoriteMovie, total);
                userFavorite.Add(userId, favorite1);
            }
     }

        public Favorite GetAllFavoriteItems(long userId)
        {
            if (userFavorite[userId].MovieItemList == null)
            {
                throw new FavoriteEmptyException();
            }
            else
            {
                return userFavorite[userId];
            }
            
        }

        public int RemoveFavoriteItem(long userId, long productId)
        {
            List<MovieItem> removeMovie = new List<MovieItem>();
            try
            {
                if (userFavorite[userId] == null)
                    throw new FavoriteEmptyException();
                else
                removeMovie = userFavorite[userId].MovieItemList;


            }
            //catch (FavoriteEmptyException ex1)
            //{
            //    Console.WriteLine(ex1.getmess());
            //    removemovie = userFavorite[userId].MovieItemList;
            //}
            catch (FavoriteEmptyException e)
            {
                Console.WriteLine(e);
            }
            MovieItem movieItem = new MovieItem();
            foreach (MovieItem item in removeMovie)
            {
                if (item.Id == productId)
                {
                    userFavorite[userId].Total -= item.Budget;
                    movieItem = item;
                    break;
                }
            }

            removeMovie.Remove(movieItem);
            if (removeMovie.Count == 0)
            {
                return 0;
            }
            return 1;
        }
    }
}
