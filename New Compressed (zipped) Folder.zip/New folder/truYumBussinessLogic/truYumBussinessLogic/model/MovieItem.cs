﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.moviecruiser.util;

namespace com.cognizant.moviecruiser.model
{
    public class MovieItem
    {

        long id;
        string name;
        float budget;
        Boolean active;
        DateTime dateOfLaunch;
        string genre;
        Boolean hasteaser;

        public long Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public float Budget
        {
            get { return budget; }
            set { budget = value; }
        }
        public Boolean Active 
        {
            get { return active; }
            set { active = value; }
        }
        public DateTime DateOfLaunch
        { 
            get{ return dateOfLaunch; }
            set{ dateOfLaunch=value; }
        }
        public string Genre
        {
            get{ return genre; }
            set{ genre=value; }
        }
        public Boolean HasTeaser
        {
            get { return hasteaser; }
            set { hasteaser = value; }
        }
        public MovieItem() { }
        public MovieItem(long id,string name,float budget,Boolean active,DateTime dateOfLaunch,string genre,Boolean hasteaser)
        {
            this.id = id;
            this.name = name;
            this.budget = budget;
            this.active = active;
            this.dateOfLaunch = dateOfLaunch;
            this.genre = genre;
            this.hasteaser = hasteaser;
        }
        public override string ToString()
        {
            //return id + "\t" + name + "\t" + budget + "\t" + active + "\t" + dateOfLaunch + "\t" + genre + "\t" + hasteaser;
            return string.Format("{0,20} {1,20 } {2,20 }{3,20 }{4,20 }{5,20 }{6,1}{7,2}{8,1}{9,4}{10,20}", Id, Name, Budget, Active, Genre, DateOfLaunch.Day,"/", DateOfLaunch.Month,"/",DateOfLaunch.Year, HasTeaser);
        }
        public override bool Equals(object obj)
        {

            MovieItem movie = obj as MovieItem;
            return this.id.Equals(movie.id);
        }
        
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
