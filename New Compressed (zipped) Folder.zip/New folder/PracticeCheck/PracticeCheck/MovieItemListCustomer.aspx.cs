﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.moviecruiser.dao;
using com.cognizant.moviecruiser.model;
using com.cognizant.moviecruiser.util;
using MovieItem = com.cognizant.moviecruiser.model.MovieItem;
using System.ComponentModel;
using System.Data;

namespace PracticeCheck
{
    public partial class MovieItemListCustomer : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            MovieItemDaoCollectionImpl movieItemDaoCollectionImpl = new MovieItemDaoCollectionImpl();
            List<MovieItem> getCustomerList = movieItemDaoCollectionImpl.GetMovieItemListCustomer();
            DataTable getAdminListTable = CreateTable.ToDataTable<MovieItem>(getCustomerList);
            GridView1.DataSource = getAdminListTable;
            GridView1.DataBind();
            
                
            
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str = GridView1.Rows[GridView1.SelectedIndex].Cells[1].Text.ToString();
            

            FavoriteDaoCollectionImpl favoriteCustomer = new FavoriteDaoCollectionImpl();
            favoriteCustomer.AddFavoriteItem(1, long.Parse(str));
            Label2.Text = "Item added to Favorite Successfully";
            
        }
    }
}